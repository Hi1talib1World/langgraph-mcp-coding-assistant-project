"""
AST Engine: Surgical AST Code Manipulation & Token Cost Savings Analyzer.
Performs node-level edits without full-file rewrites, reducing token consumption by 70%+.
"""

import ast
import difflib
import logging
from typing import Tuple, Optional, Dict, Any

logger = logging.getLogger("ASTEngine")

class FunctionNodeReplacer(ast.NodeTransformer):
    """AST Transformer that finds and replaces a specific FunctionDef or AsyncFunctionDef node by name."""
    def __init__(self, target_name: str, replacement_node: ast.AST):
        self.target_name = target_name
        self.replacement_node = replacement_node
        self.replaced = False

    def visit_FunctionDef(self, node: ast.FunctionDef) -> ast.AST:
        if node.name == self.target_name:
            logger.info(f"[ASTEngine] Matched FunctionDef node: '{self.target_name}'")
            self.replaced = True
            return ast.copy_location(self.replacement_node, node)
        return self.generic_visit(node)

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> ast.AST:
        if node.name == self.target_name:
            logger.info(f"[ASTEngine] Matched AsyncFunctionDef node: '{self.target_name}'")
            self.replaced = True
            return ast.copy_location(self.replacement_node, node)
        return self.generic_visit(node)


class ASTEngine:
    """Core AST parsing and surgical node replacement engine."""

    @staticmethod
    def parse_code(code: str) -> Optional[ast.AST]:
        """Parses Python source code into an Abstract Syntax Tree (AST)."""
        try:
            return ast.parse(code)
        except SyntaxError as e:
            logger.error(f"[ASTEngine] Syntax error parsing Python code: {e}")
            return None

    @staticmethod
    def locate_function(code: str, function_name: str) -> Optional[ast.FunctionDef]:
        """Locates a target FunctionDef or AsyncFunctionDef node in code."""
        tree = ASTEngine.parse_code(code)
        if not tree:
            return None
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name == function_name:
                return node
        return None

    @staticmethod
    def extract_function_source(code: str, function_name: str) -> Optional[str]:
        """Extracts exact source code string of a target function node."""
        node = ASTEngine.locate_function(code, function_name)
        if node:
            return ast.unparse(node)
        return None

    @staticmethod
    def patch_function_node(
        source_code: str, 
        target_name: str, 
        replacement_code: str
    ) -> Tuple[str, str, bool]:
        """
        Surgically replaces the target_name function node in source_code with replacement_code.
        Returns (patched_source_code, unified_diff, success_flag).
        """
        try:
            original_tree = ast.parse(source_code)
            replacement_tree = ast.parse(replacement_code)
        except SyntaxError as e:
            return source_code, f"SyntaxError: {str(e)}", False

        new_func_node = None
        for node in replacement_tree.body:
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                new_func_node = node
                break

        if not new_func_node:
            return source_code, "Error: Replacement code must contain a valid function definition.", False

        transformer = FunctionNodeReplacer(target_name, new_func_node)
        patched_tree = transformer.visit(original_tree)
        ast.fix_missing_locations(patched_tree)

        if not transformer.replaced:
            logger.info(f"[ASTEngine] Function '{target_name}' not found. Appending node to module body.")
            patched_tree.body.append(new_func_node)

        patched_code = ast.unparse(patched_tree)

        diff_lines = list(difflib.unified_diff(
            source_code.splitlines(keepends=True),
            patched_code.splitlines(keepends=True),
            fromfile="a/" + target_name,
            tofile="b/" + target_name,
        ))
        unified_diff = "".join(diff_lines)

        return patched_code, unified_diff, True

    @staticmethod
    def calculate_token_savings(full_file_code: str, target_func_code: str) -> Dict[str, Any]:
        """
        Calculates token and cost reduction achieved by sending only the target function AST node
        instead of full repository files to the LLM.
        """
        full_tokens = len(full_file_code.split())
        target_tokens = len(target_func_code.split())
        
        saved_tokens = max(0, full_tokens - target_tokens)
        reduction_percentage = round((saved_tokens / max(1, full_tokens)) * 100, 2)
        
        return {
            "full_file_tokens_approx": full_tokens,
            "ast_node_tokens_approx": target_tokens,
            "saved_tokens_approx": saved_tokens,
            "reduction_percentage": reduction_percentage
        }


def patch_function_node(source_code: str, target_name: str, replacement_code: str) -> Tuple[str, str, bool]:
    """Helper shortcut for ASTEngine.patch_function_node."""
    return ASTEngine.patch_function_node(source_code, target_name, replacement_code)


def calculate_token_savings(full_file_code: str, target_func_code: str) -> Dict[str, Any]:
    """Helper shortcut for ASTEngine.calculate_token_savings."""
    return ASTEngine.calculate_token_savings(full_file_code, target_func_code)


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    
    full_code = """import math
import sys

def calculate_discount(total: float, discount_percent: float) -> float:
    # Buggy implementation
    return total * (1 - discount_percent/100)

def unused_large_function_1():
    pass

def unused_large_function_2():
    pass
"""

    replacement = """def calculate_discount(total: float, discount_percent: float) -> float:
    if total < 0 or discount_percent < 0 or discount_percent > 100:
        raise ValueError("Invalid discount bounds")
    return round(total * (1 - discount_percent/100), 2)
"""

    patched, diff, ok = patch_function_node(full_code, "calculate_discount", replacement)
    savings = calculate_token_savings(full_code, replacement)
    
    print("--- AST SURGICAL DIFF ---")
    print(diff)
    print("--- TOKEN SAVINGS ANALYSIS ---")
    print(f"Full File Tokens: {savings['full_file_tokens_approx']}")
    print(f"AST Node Tokens:  {savings['ast_node_tokens_approx']}")
    print(f"Token Reduction:  {savings['reduction_percentage']}% Saved!")
